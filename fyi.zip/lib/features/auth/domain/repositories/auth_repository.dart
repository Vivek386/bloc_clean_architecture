
import 'package:dartz/dartz.dart';
import 'package:gorouter/core/errors/failure.dart';
import 'package:gorouter/core/utils/typedef.dart';
import 'package:gorouter/features/auth/domain/entities/user.dart';

abstract class AuthRepository{
  const AuthRepository();

 ResultVoid createUser({required String createdAt, required String name, required String avatar});
 ResultFuture<List<User>> getUsers();
}