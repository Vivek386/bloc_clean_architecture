import 'package:equatable/equatable.dart';

class User extends Equatable{
  User({
    this.id,
    this.createdAt,
    this.name,
    this.avatar
});

  final int? id;
  final String? createdAt;
  final String? name;
  final String? avatar;

  @override
  // TODO: implement props
  List<Object?> get props => [id];


}